#condicional


numero =8
numero =int(input("posa un numero"))
if numero==8:
    print(f"numero {numero}")
    print(f"numero {numero}")
    print(f"numero {numero}")
    print(f"numero {numero}")
elif numero==10:
    print(f"numero que sembla 10 {numero}")
    print(f"numero que sembla 10 {numero}")
else:
    print(f"mal {numero}")
    print(f"mal {numero}")
    print(f"mal {numero}")


print(f"aquest linia s'escriu si o si numero {numero}")
