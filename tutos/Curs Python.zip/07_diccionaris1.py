#diccionaris
#tenen claus úniques i valors
#buit
diccionari ={}
print (diccionari)
diccionari={1:"juanito",2:"federico",5:"alejandro"}
print (diccionari)
print (diccionari[2])
print (diccionari.get(10,"no existeix"))
print (11 in diccionari)
print (1 in diccionari)
print (diccionari.keys())
print (diccionari.values())
print (diccionari.items())
print (len(diccionari))
diccionari.clear()
