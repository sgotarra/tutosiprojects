def funcio():
    print ("holaquetal")

def funcio(name):
    print (f"hola que tal {name}")

def funcio(nema):
    return "retorna una string"


a=funcio("pepe")
print (a)

