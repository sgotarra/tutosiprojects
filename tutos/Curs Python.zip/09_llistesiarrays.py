# llistes i arrays
smartphone = ["nokia", "samsung", "pryca", "dia"]

print(smartphone[3])

# alerta al truco del almendruco

print(smartphone[-1])  # es el ultim de la llista
print(smartphone[-2])  # es el penultim de la llista

del smartphone[2]  # per a borrar
print(smartphone)

smartphone.remove ("nokia")
print(smartphone)

smartphone.insert(0,"pepe")
print(smartphone)
smartphone.insert(0,"pepe2")
print(smartphone)
smartphone.insert(2,"pepe3")
print(smartphone)
smartphone.insert(-2,"cocoliso")
print(smartphone)