#bucle for

for n  in  [2,3,4,"juliol",7]:
        print (f"element: {n}")

coleccio = { "xq",3,4,5,1231231,3.4}
for n in coleccio:
        print (f"element {n}")

coleccioregistres ={1:"juanito",2:"peoe", 3:"julai"}
for n in coleccioregistres:
    print(f" {n}   {coleccioregistres[n]}")

for clave, valor in coleccioregistres.items():
    print(f"{clave} .... {valor}")


coleccio ="cadenastring"
for n in coleccio:
    print (f"{n} ", end=" ")   #defineix el canvi de linia
    