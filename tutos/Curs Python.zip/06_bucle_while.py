#bucle while
import math

numero = int(input("numero: "))

while numero<0:
    print ("error")
    numero = int(input("numero positiu: "))

print(f"arrel cuadrada és {math.sqrt(numero):.2f}")
#:.2f es float amb 2 decimals

i=0
while (i<10):
    print(i)
    i+=1  #i = i+1

