#diccionaris

diccionari = {}
#esta buit

print (diccionari)
diccionari = {"blau":"blue","vermell":"red","verd":"green"}
print (diccionari)

print (diccionari["blau"])

diccionari["groc"]="yellow"
print (diccionari)

diccionari["groc"]="YELLOW"
del diccionari["verd"]
print (diccionari)

dicciona = {"43412267C":["SERGI","PEREZ",55,"HOME"], "44452322B":["JUANITO","HUMUS",43,"HOME"]}

print (dicciona)

dicciona={"nevera1":{"gambas":2,"cola":4}}   #diccionari de diccionaris
print (dicciona)
