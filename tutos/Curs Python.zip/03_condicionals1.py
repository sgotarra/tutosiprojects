#condicionals
edat = int (input("edat"))

if edat>0:
    print("edat ok")
    if edat>=18:
        print ("major d'edat")
    else:
        print ("enano")
else:
    print ("edat mal")

if edat>0 and edat<100:
    print ("guai bona edat")

#es pot escriure igual així
if 0<edat<100:
    print ("be")


